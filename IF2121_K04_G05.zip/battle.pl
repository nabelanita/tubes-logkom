/* BATTLE */
/* Nama2 fungsi masih belom fix */

attack :-
/* panggil fungsi untuk ngurangin health enemy */

specialAttack :-
/* panggil fungsi untuk ngurangin health enemy */

usePotion :-
/* panggil fungsi untuk menambahkan health player */

run :-
/* panggil fungsi untuk ngerandom apakah player berhasil kabur atau tidak */
/* kalau berhasil, panggil fungsi untuk keluar dari battle */
/* kalau tidak berhasil, panggil fungsi untuk ngalihin turn ke enemy*/